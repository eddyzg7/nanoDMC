/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 *  Copyright � 2014 by IEEE.
 *
 *  This source file is an essential part of IEEE P1906.1,
 *  Recommended Practice for Nanoscale and Molecular
 *  Communication Framework.
 *  Verbatim copies of this source file may be used and
 *  distributed without restriction. Modifications to this source
 *  file as permitted in IEEE P1906.1 may also be made and
 *  distributed. All other uses require permission from the IEEE
 *  Standards Department (stds-ipr@ieee.org). All other rights
 *  reserved.
 *
 *  This source file is provided on an AS IS basis.
 *  The IEEE disclaims ANY WARRANTY EXPRESS OR IMPLIED INCLUDING
 *  ANY WARRANTY OF MERCHANTABILITY AND FITNESS FOR USE FOR A
 *  PARTICULAR PURPOSE.
 *  The user of the source file shall indemnify and hold
 *  IEEE harmless from any damages or liability arising out of
 *  the use thereof.
 *
 * Author: Giuseppe Piro - Telematics Lab Research Group
 *                         Politecnico di Bari
 *                         giuseppe.piro@poliba.it
 *                         telematics.poliba.it/piro
 *
 * Editors: Paúl Calderón - Eddy Zúñiga	-	Students of the University of Cuenca - Ecuador
 * 											paul.calderon06@ucuenca.edu.ec
 * 											eddy.zuniga@ucuenca.edu.ec
 * 											30/04/2021
 */


/*
 * Description:
 * this file models the simple example of MOLECULAR-based communication.
 * xxx: add more comments (i.e., description of the scenario)
 */

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/mobility-module.h"
#include "ns3/p1906-helper.h"
#include "ns3/p1906-net-device.h"
#include "ns3/p1906-mol-perturbation.h"
#include "ns3/p1906-mol-field.h"
#include "ns3/p1906-mol-motion.h"
#include "ns3/p1906-mol-specificity.h"
#include "ns3/p1906-medium.h"
#include "ns3/p1906-mol-communication-interface.h"
#include "ns3/p1906-mol-transmitter-communication-interface.h"
#include "ns3/p1906-mol-receiver-communication-interface.h"
#include "ns3/ptr.h"
#include "ns3/packet.h"
#include "ns3/header.h"
#include <iostream>
#include <math.h>
#include <time.h>
#define BROWNIANMOTION 0;
#define BROWNIANMOTIONDRIFT 1;

using namespace ns3;

int main (int argc, char *argv[])
{	

  srand( time(NULL) );
  //set of parameters
  double nodeDistance = 50 * pow(10,-6); 					// [m]
  double nbOfMol = 120000; 								// [pJ]
  double pulseInterval = 7000;								// [ms]
  double diffusionCoefficient = 1;							// [nm^2/ns]
  double driftVelocity = 100 * pow(10,-6);					// [m/s]
  double driftAngule = M_PI*0; 								// [rad]
  double timeSlot = 260;									// Number of time slots divided by simulation time (ts)
  double limitMolOne = nbOfMol*0.35;					// Limit of molecules received for detection of bit one
  double receptionRadio = 8 * pow(10,-6);					// Reception Radio
  int motionFreeOrDrift = BROWNIANMOTION;					// BROWNIANMOTION/BROWNIANMOTIONDRIFT
  double upLimitVein = 0.0500;								// Upper limit of vein
  double lowLimitVein = -0.0500;							// Lower limit of vein
  size_t pktSize = 1;										// Number of packages (bytes) to send


  CommandLine cmd;
  cmd.AddValue("nodeDistance", "nodeDistance", nodeDistance);
  cmd.AddValue("nbOfMol", "nbOfMol", nbOfMol);
  cmd.AddValue("diffusionCoefficient", "diffusionCoefficient", diffusionCoefficient);
  cmd.AddValue("pulseInterval", "pulseInterval", pulseInterval);
  cmd.AddValue("driftVelocity", "driftVelocity", driftVelocity);
  cmd.AddValue("driftAngule", "driftAngule", driftAngule);
  cmd.AddValue("timeSlot", "timeSlot", timeSlot);
  cmd.AddValue("limitMolOne", "limitMolOne", limitMolOne);
  cmd.AddValue("receptionRadio", "receptionRadio", receptionRadio);
  cmd.AddValue("motionFreeOrDrift", "motionFreeOrDrift", motionFreeOrDrift);
  cmd.AddValue("upLimitVein", "upLimitVein", upLimitVein);
  cmd.AddValue("lowLimitVein", "lowLimitVein", lowLimitVein);
  cmd.AddValue("pktSize", "pktSize", pktSize);
  cmd.Parse(argc, argv);

  diffusionCoefficient = diffusionCoefficient * 1e-9;

  Time::SetResolution(Time::NS);

  // Create P1906 Helper
  P1906Helper helper;
  helper.EnableLogComponents ();

  // Create nodes (typical operation of ns-3)
  NodeContainer n;
  NetDeviceContainer d;
  n.Create (2);

  // Create a medium and the Motion component
  Ptr<P1906Medium> medium = CreateObject<P1906Medium> ();
  Ptr<P1906MOLMotion> motion = CreateObject<P1906MOLMotion> ();
  motion->SetDiffusionCoefficient (diffusionCoefficient);
  motion->SetLimitVein(lowLimitVein, upLimitVein);
  medium->SetP1906Motion (motion);
  medium->SetMotionFreeOrDrift(motionFreeOrDrift);
  medium->SetnOfMol(nbOfMol);
  medium->Setpos(nodeDistance);
  medium->SetSlot(timeSlot);
  medium->SetRadio(receptionRadio);

  // Create Device 1 and related components/entities
  Ptr<P1906NetDevice> dev1 = CreateObject<P1906NetDevice> ();
  Ptr<P1906MOLCommunicationInterface> c1 = CreateObject<P1906MOLCommunicationInterface> ();
  Ptr<P1906MOLSpecificity> s1 = CreateObject<P1906MOLSpecificity> ();
  Ptr<P1906MOLField> fi1 = CreateObject<P1906MOLField> ();
  Ptr<P1906MOLPerturbation> p1 = CreateObject<P1906MOLPerturbation> ();

  // Create Device 2 and related components/entities
  Ptr<P1906NetDevice> dev2 = CreateObject<P1906NetDevice> ();
  Ptr<P1906MOLCommunicationInterface> c2 = CreateObject<P1906MOLCommunicationInterface> ();
  Ptr<P1906MOLSpecificity> s2 = CreateObject<P1906MOLSpecificity> ();
  Ptr<P1906MOLField> fi2 = CreateObject<P1906MOLField> ();
  Ptr<P1906MOLPerturbation> p2 = CreateObject<P1906MOLPerturbation> ();

  //Set devices positions
  Ptr<ListPositionAllocator> positionAlloc = CreateObject<ListPositionAllocator> ();
  positionAlloc->Add (Vector(0, 0, 0));
  positionAlloc->Add (Vector(nodeDistance, 0, 0));
  MobilityHelper mobility;
  mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
  mobility.SetPositionAllocator(positionAlloc);
  mobility.Install(n);

  d.Add (dev1);
  d.Add (dev2);
  // Set attributes to devices
  helper.SetAtribDevice(c1, s1, fi1, p1, nbOfMol, limitMolOne, pulseInterval,
		  diffusionCoefficient, driftAngule, driftVelocity, nodeDistance);
  helper.SetAtribDevice(c2, s2, fi2, p2, nbOfMol, limitMolOne, pulseInterval,
		  diffusionCoefficient, driftAngule, driftVelocity, nodeDistance);
  // Connect devices, nodes, medium, components and entities
  helper.Connect(n.Get (0),dev1,medium,c1,fi1, p1,s1);
  helper.Connect(n.Get (1),dev2,medium,c2,fi2, p2,s2);


  // Create a message to sent into the network
  //size_t pktSize = 1; //bytes
  uint8_t *buffer  = new uint8_t[pktSize];
  /*for (size_t i = 0; i < pktSize; i++){
	  buffer[i] = 0;
	  for (size_t j=0; j<8;j++){
		  buffer[i] |= rand()%2 << j;
		  //buffer[i] |= 1 << j;
	  }
    }*/


  buffer[0] = 0;
  buffer[0] |= 0 << 0;
  buffer[0] |= 0 << 1;
  buffer[0] |= 0 << 2;
  buffer[0] |= 0 << 3;
  buffer[0] |= 0 << 4;
  buffer[0] |= 0 << 5;
  buffer[0] |= 0 << 6;
  buffer[0] |= 1 << 7;

  /*buffer[0] = 0;
  buffer[0] |= 1 << 0;
  buffer[0] |= 0 << 1;
  buffer[0] |= 0 << 2;
  buffer[0] |= 1 << 3;
  buffer[0] |= 1 << 4;
  buffer[0] |= 0 << 5;
  buffer[0] |= 1 << 6;
  buffer[0] |= 1 << 7;*/

  /*buffer[1] = 0;
  buffer[1] |= 1 << 0;
  buffer[1] |= 0 << 1;
  buffer[1] |= 1 << 2;
  buffer[1] |= 0 << 3;
  buffer[1] |= 1 << 4;
  buffer[1] |= 0 << 5;
  buffer[1] |= 0 << 6;
  buffer[1] |= 1 << 7;*/

  Ptr<Packet> message = Create<Packet>(buffer, pktSize);
  c1->HandleTransmission (message);


  Simulator::Run ();
  Simulator::Destroy ();
  return 0;
}
