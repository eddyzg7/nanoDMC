/* -- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -- */
/*
 *  Copyright © 2014 by IEEE.
 *
 *  This source file is an essential part of IEEE Std 1906.1,
 *  Recommended Practice for Nanoscale and Molecular
 *  Communication Framework.
 *  Verbatim copies of this source file may be used and
 *  distributed without restriction. Modifications to this source
 *  file as permitted in IEEE Std 1906.1 may also be made and
 *  distributed. All other uses require permission from the IEEE
 *  Standards Department (stds-ipr@ieee.org). All other rights
 *  reserved.
 *
 *  This source file is provided on an AS IS basis.
 *  The IEEE disclaims ANY WARRANTY EXPRESS OR IMPLIED INCLUDING
 *  ANY WARRANTY OF MERCHANTABILITY AND FITNESS FOR USE FOR A
 *  PARTICULAR PURPOSE.
 *  The user of the source file shall indemnify and hold
 *  IEEE harmless from any damages or liability arising out of
 *  the use thereof.
 *
 * Author: Giuseppe Piro - Telematics Lab Research Group
 *                         Politecnico di Bari
 *                         giuseppe.piro@poliba.it
 *                         telematics.poliba.it/piro
 *
 * Editors: Paúl Calderón - Eddy Zúñiga	-	Students of the University of Cuenca - Ecuador
 * 											paul.calderon06@ucuenca.edu.ec
 * 											eddy.zuniga@ucuenca.edu.ec
 * 											30/04/2021
 */

#include "ns3/log.h"

#include "p1906-mol-motion.h"
#include "ns3/p1906-communication-interface.h"
#include "ns3/p1906-message-carrier.h"
#include "ns3/p1906-field.h"
#include "ns3/mobility-model.h"
#include "ns3/p1906-net-device.h"
#include <ns3/spectrum-value.h>
#include "p1906-mol-message-carrier.h"
#include <iostream>
#include <chrono>
#include <random>
#include <vector>
#include <cmath>
#include <math.h>
#include <sstream>
#include <iomanip>
#include <string>
#include <algorithm>


  /*
   *The Motion component implements a propagation model as presented in
   * Detection Techniques for Diffusion-based Molecular Communication
   * I Llatser, A Cabellos-Aparicio, M Pierobon, E Alarcón
   * Selected Areas in Communications, IEEE Journal on 31 (12), 726-734
   */


namespace ns3 {

std::vector <std::vector<double> > BrownianMotion ();
NS_LOG_COMPONENT_DEFINE ("P1906MOLMotion");

TypeId P1906MOLMotion::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::P1906MOLMotion")
    .SetParent<P1906Motion> ();
  return tid;
}

P1906MOLMotion::P1906MOLMotion ()
{
  NS_LOG_FUNCTION (this);
}

P1906MOLMotion::~P1906MOLMotion ()
{
  NS_LOG_FUNCTION (this);
}


double
P1906MOLMotion::ComputePropagationDelay (Ptr<P1906CommunicationInterface> src,
		                                Ptr<P1906CommunicationInterface> dst,
		                                Ptr<P1906MessageCarrier> message,
		                                Ptr<P1906Field> field)
{
  NS_LOG_FUNCTION (this << "Fick's law");

  Ptr<MobilityModel> srcMobility = src->GetP1906NetDevice ()->GetNode ()->GetObject<MobilityModel> ();
  Ptr<MobilityModel> dstMobility = dst->GetP1906NetDevice ()->GetNode ()->GetObject<MobilityModel> ();


  double distance = dstMobility->GetDistanceFrom (srcMobility);

  //Delay in 3D
  //double delay = pow(distance,2)/(GetDiffusionConefficient ()*6);

  //Delay in 2D
  double delay = pow(distance,2)/(GetDiffusionConefficient ()*4);
  double diffusion = GetDiffusionConefficient ();

  NS_LOG_FUNCTION (this << "[dist,diffusion,delay]" << distance <<  diffusion << delay);

  return delay;
}

double
P1906MOLMotion::ComputeRVGauss (double media, double var)
{
  double RV;
  unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
  std::default_random_engine generator (seed);
  std::normal_distribution<double> distribution (media,var);

  for (int i=0; i<10; ++i)
	RV = distribution(generator);
  return RV;
}

std::vector <std::vector<double> >
P1906MOLMotion::BrownianMotion (std::vector <std::vector<double> > vectorXY)
{
  double xi = 0;
  double yi = 0;
  double m_theta = 0.;
  double e = 1; 							//Coeficiente de restitucion
  double u = 0;								//Coeficiente de friccion
  double m_theta1 = 0.;						//Angulo reflexion
  double ha = 0;
  double L = 0;
  double mod = 0;
  double mod1 = 0;
  double x1 = 0;
  double y1 = 0;

  std::string xy = "";
  std::vector <double> x;
  std::vector <double> y;


  for (int i = 0; i < m_nOfMol; i++){
	  m_theta = ComputeRVGauss(0.0,2*M_PI);
	  if (vectorXY[i][0] == 1){
		  xi = vectorXY[i][2];
		  yi = vectorXY[i][3];
	  } else {
		  xi = vectorXY[i][2] + sqrt(4*m_diffusionCoefficient*m_deltat) * cos(m_theta);//Crear una variable para la raiz y sacar del for
		  yi = vectorXY[i][3] + sqrt(4*m_diffusionCoefficient*m_deltat) * sin(m_theta);
		  if (yi > m_uplimitvein || yi < m_lowlimitvein){
			  m_theta1 = atan(((tan(m_theta)-u)/e)-u);//revisar OJO
			  m_theta1 = m_theta;
			  ha = abs(m_uplimitvein - abs(vectorXY[i][3]));
			  mod = ha/abs(sin(m_theta));
			  L = mod*abs(cos(m_theta));
			  mod1 = abs(sqrt(4*m_diffusionCoefficient*m_deltat) - mod);
			  if (vectorXY[i][2] < xi){ //Rebota ADELANTE
				  if (yi > m_uplimitvein){ // Limite Superior
					  x1 = vectorXY[i][2]+L;
					  y1 = vectorXY[i][3]+ha;
					  xi = x1 + mod1 * abs(cos(m_theta1));  //X2
					  yi = y1 - mod1 * abs(sin(m_theta1));  //Y2
				  } else { // Limite Inferior
					  x1 = vectorXY[i][2]+L;
					  y1 = vectorXY[i][3]-ha;
					  xi = x1 + mod1 * abs(cos(m_theta1));  //X2
					  yi = y1 + mod1 * abs(sin(m_theta1));  //Y2
				  }
			  } else { //Rebota ATRAS
				  if (yi > m_uplimitvein){ // Limite Superior
					  x1 = vectorXY[i][2]-L;
					  y1 = vectorXY[i][3]+ha;
					  xi = x1 + mod1 * abs(cos(m_theta1));  //X2
					  yi = y1 - mod1 * abs(sin(m_theta1));  //Y2
				  } else { // Limite Inferior
					  x1 = vectorXY[i][2]-L;
					  y1 = vectorXY[i][3]-ha;
					  xi = x1 - mod1 * abs(cos(m_theta1));  //X2
					  yi = y1 + mod1 * abs(sin(m_theta1));  //Y2
				  }
			  }
		  }
	  }
	vectorXY [i][2] = xi;
	vectorXY [i][3] = yi;
  }
  return vectorXY;
}

std::vector <std::vector<double> >
P1906MOLMotion::BrownianMotionDrift (std::vector <std::vector<double> > vectorXY, Ptr<P1906Field> field)
{

  double xi = 0;
  double yi = 0;
  double m_theta = 0.;
  double e = 1; 							//Coeficiente de restitucion
  double u = 0;								//Coeficiente de friccion
  double m_theta1 = 0.;						//Angulo reflexion
  double ha = 0;
  double L = 0;
  double mod = 0;
  double mod1 = 0;
  double x1 = 0;
  double y1 = 0;
  double vel = field->GetVelocityDrift();
  double anguledrift = field->GetAngleDrift();


  std::string xy = "";
  std::vector <double> x;
  std::vector <double> y;

  for (int i = 0; i < m_nOfMol; i++){
	  m_theta = ComputeRVGauss(0.0,2*M_PI);
	  if (vectorXY[i][0] == 1){
		  xi = vectorXY[i][2];
		  yi = vectorXY[i][3];
	  } else {
		  xi = vectorXY[i][2] + sqrt(4*m_diffusionCoefficient*m_deltat) * cos(m_theta) + vel * cos(anguledrift) * m_deltat;
		  yi = vectorXY[i][3] + sqrt(4*m_diffusionCoefficient*m_deltat) * sin(m_theta) + vel * sin(anguledrift) * m_deltat;
		  if (yi > m_uplimitvein || yi < m_lowlimitvein){
			  m_theta1 = atan(((tan(m_theta)-u)/e)-u);// Condition for rebound angle
			  m_theta1 = m_theta;
			  ha = abs(m_uplimitvein - abs(vectorXY[i][3]));
			  mod = ha/abs(sin(m_theta));
			  L = mod*abs(cos(m_theta));
			  mod1 = abs(sqrt(4*m_diffusionCoefficient*m_deltat) - mod);
			  if (vectorXY[i][2] < xi){ //Rebota ADELANTE
				  if (yi > m_uplimitvein){ // Limite Superior
					  x1 = vectorXY[i][2]+L;
					  y1 = vectorXY[i][3]+ha;
					  xi = x1 + mod1 * abs(cos(m_theta1));  //X2
					  yi = y1 - mod1 * abs(sin(m_theta1));  //Y2
				  } else { // Limite Inferior
					  x1 = vectorXY[i][2]+L;
					  y1 = vectorXY[i][3]-ha;
					  xi = x1 + mod1 * abs(cos(m_theta1));  //X2
					  yi = y1 + mod1 * abs(sin(m_theta1));  //Y2
				  }
			  } else { //Rebota ATRAS
				  if (yi > m_uplimitvein){ // Limite Superior
					  x1 = vectorXY[i][2]-L;
					  y1 = vectorXY[i][3]+ha;
					  xi = x1 + mod1 * abs(cos(m_theta1));  //X2
					  yi = y1 - mod1 * abs(sin(m_theta1));  //Y2
				  } else { // Limite Inferior
					  x1 = vectorXY[i][2]-L;
					  y1 = vectorXY[i][3]-ha;
					  xi = x1 - mod1 * abs(cos(m_theta1));  //X2
					  yi = y1 + mod1 * abs(sin(m_theta1));  //Y2
				  }
			  }
		  }
	  }
	vectorXY [i][2] = xi;
	vectorXY [i][3] = yi;
  }
  return vectorXY;

}


Ptr<P1906MessageCarrier>
P1906MOLMotion::CalculateReceivedMessageCarrier(Ptr<P1906CommunicationInterface> src,
		                                       Ptr<P1906CommunicationInterface> dst,
											   Ptr<P1906MessageCarrier> message,
											   std::vector < std::vector<double> > RxTime,
		                                       Ptr<P1906Field> field)
{

  NS_LOG_FUNCTION (this << "Do nothing for the Fick's low");
  std::vector <double> time;
  std::vector <std::vector<double>> time1;
  std::vector <double> cont;

  double contador=0;
  double t0=0;
  double t1;
  double t2;
  int cg =0;
  int nmol;
  std::vector <std::vector<double> > TimeBit (m_numpaquet*8*m_nOfMol, std::vector<double>(3,0));
  std::vector <double> TimeBit1;
  std::vector <double> TimeBit2;
  std::vector <int> N_Mol;
  std::vector <double> aux (m_numpaquet*8);
  std::string moleculeswithoutISI = "";
  std::string moleculeswithISI = "";
  int aux1;
  std::vector <int> aux2;

  std::vector <std::vector<int> > bits (m_numpaquet, std::vector<int>(8,0));
  for (int i=0; i<int(RxTime.size()); i++){ //Matriz con todos los tiempos de cada bit
	  time.resize(0);
	  for (int j=0; j<int(RxTime[i].size()); j++){ //Sacamos fila por fila los tiempos
		  if (RxTime[i][j] !=0){
			  time.push_back(RxTime[i][j]);
		  }
	  }
	  sort(time.begin(),time.end()); //Ordenamos el vector tiempo

	  t2=m_ts;
	  t1=0;
	  if(i>0){
		  t0=m_delay-(m_tw/2);
	  }
	  for(int k=1;k<(m_numpaquet*8)+1; k++){
		  if(k>1){
			  t0=m_ts;
			  t1=(k-2)*m_tw;
			  t2=m_ts+(k-1)*m_tw;
		  }
		  else{
			  if(i==0){
				  t0=0;
				  t1=0;
			  }
		  }
		  for(int l=0;l<int(time.size());l++){
			  if((time[l]>(t0+t1)) & (time[l]<=t2)){ //Condiciones para contar
				  TimeBit[cg][0] = time[l] + i*m_tw;
				  TimeBit[cg][1] = k-1;
				  TimeBit[cg][2] = i;
				  cg = cg + 1;
				  contador=contador+1;
			  }
		  }
		  cont.push_back(contador);
		  contador = 0;
	  }

	  time1.push_back(cont);
	  cont.resize(0);
  }


  for(int ls = 0; ls<int(TimeBit.size()); ls++){
	  if(TimeBit[ls][0]!=0){
		  TimeBit1.push_back(TimeBit[ls][0]);
	  }
  }

  sort(TimeBit1.begin(),TimeBit1.end());

  t0=0;
  t1=0;
  t2=m_ts;
  nmol=1;
  //N_Mol.push_back(0);
  for(int ln=1;ln<(m_numpaquet*8)+1;ln++){			//Concentración máxima de moléculas por cada bit
	  if(ln>1){
		  t0=m_ts;
		  t1=(ln-2)*m_tw;
		  t2=m_ts+(ln-1)*m_tw;
	  }
	  for(int lm=0;lm<int(TimeBit1.size());lm++){
		  if((TimeBit1[lm]>(t0+t1)) & (TimeBit1[lm]<=t2)){
			  TimeBit2.push_back(TimeBit1[lm]);
		  }
	  }
	  for(int ls=0;ls<int(TimeBit2.size());ls++){
		  if(ls==int(TimeBit2.size())-1){
			  break;
		  }
		  else if(TimeBit2[ls]==TimeBit2[ls+1]){
			  nmol=nmol+1;
		  }
		  else{
			  N_Mol.push_back(nmol);
			  nmol=1;
		  }
	  }

	  for(int lh=0;lh<int(N_Mol.size());lh++){//Sacamos el numero maximo
		  if(lh==0){
			  aux1 = N_Mol[0];
		  } else if(N_Mol[lh]>aux1){
			  aux1=N_Mol[lh];
		  }
	  }
	  aux2.push_back(aux1);
	  N_Mol.resize(0);
	  //N_Mol.push_back(0);
	  TimeBit2.resize(0);

  }


  double cnt=0;
  for (int i = (m_numpaquet*8)-1; i >= 0; i--){ //Sumar el numero de moleculas con ISI
	  for (int j = 0; j < (m_numpaquet*8)-cnt; j++){
		  aux[i] = aux[i] + time1[i-j][j];
	  }
	  cnt=cnt+1;
  }

  int h = 0;
  for(int i=0; i<m_numpaquet; i++){ //Guardar en formato paquete
	  for(int j=0; j<8; j++){
		  bits[i][j]=int(aux2[h]);
		  h=h+1;
	  }
  }

  for(int i=0; i<int(time1.size()); i++){ //Visualizar moléculas sin ISI
	  moleculeswithoutISI = moleculeswithoutISI + std::to_string(time1[i][0])+" | ";
    }
  NS_LOG_FUNCTION("Molecules without ISI: " << moleculeswithoutISI);

  for(int i=0; i<int(aux.size()); i++){ //Visualizar moléculas con ISI
	  moleculeswithISI = moleculeswithISI + std::to_string(aux[i])+" | ";
      }
  NS_LOG_FUNCTION("Molecules with ISI:    " << moleculeswithISI);

  message->SetModulation(bits);


  return message;
}

void
P1906MOLMotion::SetDiffusionCoefficient (double d)
{
  NS_LOG_FUNCTION (this << d);
  m_diffusionCoefficient = d;
}

double
P1906MOLMotion::GetDiffusionConefficient (void)
{
  NS_LOG_FUNCTION (this);
  return m_diffusionCoefficient;
}

double
P1906MOLMotion::Getdelay (void)
{
  NS_LOG_FUNCTION (this);
  return m_delay;
}

void
P1906MOLMotion::Setdelay (double d)
{
  NS_LOG_FUNCTION (this << d);
  m_delay = d;
}

double
P1906MOLMotion::GetnOfMol (void)
{
  NS_LOG_FUNCTION (this);
  return m_nOfMol;
}

void
P1906MOLMotion::SetnOfMol (double nOfMol)
{
  NS_LOG_FUNCTION (this << nOfMol);
  m_nOfMol = nOfMol;
}

double
P1906MOLMotion::GetDeltat (void)
{
  NS_LOG_FUNCTION (this);
  return m_deltat;
}

void
P1906MOLMotion::SetDeltat (double deltat)
{
  NS_LOG_FUNCTION (this << deltat);
  m_deltat = deltat;
}

double
P1906MOLMotion::GetTimeTs (void)
{
  NS_LOG_FUNCTION (this);
  return m_ts;
}

void
P1906MOLMotion::SetTimeTs (double ts)
{
  NS_LOG_FUNCTION (this << ts);
  m_ts = ts;
}

int
P1906MOLMotion::GetNumPaquet (void)
{
  NS_LOG_FUNCTION (this);
  return m_numpaquet;
}

void
P1906MOLMotion::SetNumPaquet (int numpaquet)
{
  NS_LOG_FUNCTION (this << numpaquet);
  m_numpaquet = numpaquet;
}

double
P1906MOLMotion::GetTw (void)
{
  NS_LOG_FUNCTION (this);
  return m_tw;
}

void
P1906MOLMotion::SetTw (double tw)
{
  NS_LOG_FUNCTION (this << tw);
  m_tw = tw;
}

void
P1906MOLMotion::SetLimitVein (double lowlimitvein, double uplimitvein)
{
  //NS_LOG_FUNCTION (this << "Lower Limit, Upper Limit: " << lowlimitvein << ", "<< uplimitvein);
  m_lowlimitvein = lowlimitvein;
  m_uplimitvein = uplimitvein;
}

} // namespace ns3
