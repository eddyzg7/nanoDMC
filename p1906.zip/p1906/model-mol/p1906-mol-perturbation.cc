/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 *  Copyright � 2014 by IEEE.
 *
 *  This source file is an essential part of IEEE P1906.1,
 *  Recommended Practice for Nanoscale and Molecular
 *  Communication Framework.
 *  Verbatim copies of this source file may be used and
 *  distributed without restriction. Modifications to this source
 *  file as permitted in IEEE P1906.1 may also be made and
 *  distributed. All other uses require permission from the IEEE
 *  Standards Department (stds-ipr@ieee.org). All other rights
 *  reserved.
 *
 *  This source file is provided on an AS IS basis.
 *  The IEEE disclaims ANY WARRANTY EXPRESS OR IMPLIED INCLUDING
 *  ANY WARRANTY OF MERCHANTABILITY AND FITNESS FOR USE FOR A
 *  PARTICULAR PURPOSE.
 *  The user of the source file shall indemnify and hold
 *  IEEE harmless from any damages or liability arising out of
 *  the use thereof.
 *
 * Author: Giuseppe Piro - Telematics Lab Research Group
 *                         Politecnico di Bari
 *                         giuseppe.piro@poliba.it
 *                         telematics.poliba.it/piro
 *
 * Editors: Paúl Calderón - Eddy Zúñiga	-	Students of the University of Cuenca - Ecuador
 * 											paul.calderon06@ucuenca.edu.ec
 * 											eddy.zuniga@ucuenca.edu.ec
 * 											30/04/2021
 */



#include "ns3/log.h"
#include "ns3/packet.h"
#include "p1906-mol-perturbation.h"
#include "ns3/p1906-message-carrier.h"
#include "ns3/p1906-perturbation.h"
#include "p1906-mol-message-carrier.h"
#include "ns3/simulator.h"
#include "ns3/spectrum-value.h"
#include <stddef.h>
#include <stdio.h>
#include <stdint.h>

namespace ns3 {


#define MOST_LEFT_BIT_UINT8 (UINT8_MAX / 2 + 1)
NS_LOG_COMPONENT_DEFINE ("P1906MOLPerturbation");

TypeId P1906MOLPerturbation::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::P1906MOLPerturbation")
    .SetParent<P1906Perturbation> ();
  return tid;
}

P1906MOLPerturbation::P1906MOLPerturbation ()
{
  NS_LOG_FUNCTION (this);
}

P1906MOLPerturbation::~P1906MOLPerturbation ()
{
  NS_LOG_FUNCTION (this);
}

void
P1906MOLPerturbation::SetPulseInterval (Time t)
{
  NS_LOG_FUNCTION (this << t);
  m_pulseInterval = t;
}

Time
P1906MOLPerturbation::GetPulseInterval (void)
{
  NS_LOG_FUNCTION (this);
  return m_pulseInterval;
}

void
P1906MOLPerturbation::SetMolecules (double q)
{
  NS_LOG_FUNCTION (this << q);
  m_mol = q;
}

double
P1906MOLPerturbation::GetMolecules (void)
{
  NS_LOG_FUNCTION (this);
  return m_mol;
}

void
P1906MOLPerturbation::SetSlot (double slot)
{
  NS_LOG_FUNCTION (this << slot);
  m_slot = slot;
}

double
P1906MOLPerturbation::GetSlot (void)
{
  NS_LOG_FUNCTION (this);
  return m_slot;
}




Ptr<P1906MessageCarrier>
P1906MOLPerturbation::CreateMessageCarrier (Ptr<Packet> p)
{
  NS_LOG_FUNCTION (this);
  Ptr<P1906MOLMessageCarrier> carrier = CreateObject<P1906MOLMessageCarrier> ();

  double duration = m_pulseInterval.GetSeconds () * p->GetSize () * 8;
  double now = Simulator::Now ().GetSeconds ();

  std::vector < std::vector<int> >  mod (int(p->GetSize()), std::vector<int>(8));
  std::string bitsTX="";
  NS_LOG_FUNCTION (this << "[t,bits,pulseI,duration]" << now << p->GetSize() * 8
		  << m_pulseInterval << duration);

  uint8_t *buffer = new uint8_t[p->GetSize ()];
  p->CopyData(buffer, p->GetSize ());

  for (int i = 0; i < int(p->GetSize()); i++) {
    for (size_t j = 0; j < 8; j++) {
      if (buffer[i] & (MOST_LEFT_BIT_UINT8 >> j)){
        bitsTX = bitsTX + "1";
        mod[i][j] = m_mol;//Cambiar nombre modulatedtData
      }
      else {
    	mod[i][j] = m_mol*0;//moléculas para el 0 son el 50% del 1
    	bitsTX = bitsTX + "0";
      }
    }
    NS_LOG_FUNCTION("Packet" << i << ":" << bitsTX);
    bitsTX="";
  }

  carrier->SetPulseInterval (m_pulseInterval);
  carrier->SetDuration (Seconds(duration));
  carrier->SetStartTime (Simulator::Now ());
  carrier->SetMolecules (GetMolecules ());
  carrier->SetMessage (p);
  carrier->SetModulation(mod);//Cambiar a CSK-OOK setModulatedData

  return carrier;
}

} // namespace ns3
