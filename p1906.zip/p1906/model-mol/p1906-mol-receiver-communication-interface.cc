/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 *  Copyright � 2014 by IEEE.
 *
 *  This source file is an essential part of IEEE P1906.1,
 *  Recommended Practice for Nanoscale and Molecular
 *  Communication Framework.
 *  Verbatim copies of this source file may be used and
 *  distributed without restriction. Modifications to this source
 *  file as permitted in IEEE P1906.1 may also be made and
 *  distributed. All other uses require permission from the IEEE
 *  Standards Department (stds-ipr@ieee.org). All other rights
 *  reserved.
 *
 *  This source file is provided on an AS IS basis.
 *  The IEEE disclaims ANY WARRANTY EXPRESS OR IMPLIED INCLUDING
 *  ANY WARRANTY OF MERCHANTABILITY AND FITNESS FOR USE FOR A
 *  PARTICULAR PURPOSE.
 *  The user of the source file shall indemnify and hold
 *  IEEE harmless from any damages or liability arising out of
 *  the use thereof.
 *
 * Author: Giuseppe Piro - Telematics Lab Research Group
 *                         Politecnico di Bari
 *                         giuseppe.piro@poliba.it
 *                         telematics.poliba.it/piro
 *
 * Editors: Paúl Calderón - Eddy Zúñiga	-	Students of the University of Cuenca - Ecuador
 * 											paul.calderon06@ucuenca.edu.ec
 * 											eddy.zuniga@ucuenca.edu.ec
 * 											30/04/2021
 */


#include "ns3/log.h"

#include "p1906-mol-receiver-communication-interface.h"
#include "ns3/p1906-net-device.h"
#include <ns3/packet.h>
#include "ns3/p1906-specificity.h"
#include "ns3/p1906-message-carrier.h"
#include "ns3/p1906-communication-interface.h"
#include "ns3/p1906-medium.h"
#include "ns3/p1906-net-device.h"
#include "ns3/p1906-motion.h"
#include "p1906-mol-specificity.h"
#include "ns3/mobility-model.h"
#include <stddef.h>
#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <algorithm>
#include <fstream>



namespace ns3 {

std::ofstream output2;
#define MOST_LEFT_BIT_UINT8 (UINT8_MAX / 2 + 1)
NS_LOG_COMPONENT_DEFINE ("P1906MOLReceiverCommunicationInterface");

TypeId P1906MOLReceiverCommunicationInterface::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::P1906MOLReceiverCommunicationInterface")
    .SetParent<P1906ReceiverCommunicationInterface> ();
  return tid;
}

P1906MOLReceiverCommunicationInterface::P1906MOLReceiverCommunicationInterface ()
{
  NS_LOG_FUNCTION (this);
}

P1906MOLReceiverCommunicationInterface::~P1906MOLReceiverCommunicationInterface ()
{
  NS_LOG_FUNCTION (this);
}

void
P1906MOLReceiverCommunicationInterface::HandleReception (Ptr<P1906CommunicationInterface> src, Ptr<P1906CommunicationInterface> dst, Ptr<P1906MessageCarrier> message, double umbral)
{


  Ptr<P1906MOLSpecificity> specificity = GetP1906Specificity ()->GetObject<P1906MOLSpecificity> ();
  bool isRxOk = specificity->CheckRxCompatibility (src, dst, message);
  Ptr<P1906NetDevice> dstNetDevice = (dst)->GetP1906NetDevice ();
  std::string file;
  std::string strBitsRX = "";
  std::string strMaxMol = "";

  Ptr<MobilityModel> srcMobility = src->GetP1906NetDevice ()->GetNode ()->GetObject<MobilityModel> ();
  Ptr<MobilityModel> dstMobility = dst->GetP1906NetDevice ()->GetNode ()->GetObject<MobilityModel> ();
  double distance = dstMobility->GetDistanceFrom (srcMobility);

  if (isRxOk)
    {
	  NS_LOG_FUNCTION (this << "message received successfully on node: " << dstNetDevice);
	  //xxx forward to upper layer
	  Ptr<Packet> p = message->GetMessage ();
	  int NumPaquet = int(p->GetSize());
	  int contBER=0;
	  file="BER-"+std::to_string(distance)+ "-" + std::to_string(m_radio) + ".csv";

	  std::vector <std::vector<int> > bitsrx (NumPaquet, std::vector<int>(8));
	  std::vector <std::vector<int> > bitstx (NumPaquet, std::vector<int>(8));
	  bitstx = GetMnsTx();
	  bitsrx = message->GetModulation();
	  uint8_t *buffer  = new uint8_t[NumPaquet];
	  umbral = bitsrx[0][0];
	  for(int i=0; i<NumPaquet; i++){
		  for(int j=0; j<7; j++){
			  if(bitsrx[i][j]<bitsrx[i][j+1]){
				  umbral = bitsrx[i][j+1];
			  }

		  }

	  }
	  umbral = ceil((float)umbral/2);

	  for (int i = 0; i < NumPaquet; i++) {
		  buffer[i] = 0;
		  for(int j=0; j<8; j++){
			  if (bitsrx[i][j]>umbral){
				  strBitsRX = strBitsRX + "1";
				  strMaxMol = strMaxMol + std::to_string(bitsrx[i][j])+"|";
				  buffer[i] |= 1 << j;
				  if(bitstx[i][j]!=m_nummol){
					  contBER=contBER+1;
				  }

			  }else{
				  strBitsRX = strBitsRX + "0";
				  strMaxMol = strMaxMol + std::to_string(bitsrx[i][j])+"|";
				  buffer[i] |= 0 << j;
				  if(bitstx[i][j]!=0){
					  contBER=contBER+1;
				  }
			  }
		  }
		  NS_LOG_FUNCTION("Packet received " << i << ": " << strBitsRX );
	  }
	  output2.open(file);
	  output2 << (float)contBER / (float)(NumPaquet*8);
	  output2.close();
	  Ptr<Packet> message = Create<Packet>(buffer, NumPaquet);
	  NS_LOG_FUNCTION("ErrorBits, Umbral, BER" << contBER << umbral << (float)contBER / (float)(NumPaquet*8));
	  NS_LOG_FUNCTION("CmaxMolecules/bit" << strMaxMol);
    }
  else
    {
	  NS_LOG_FUNCTION (this << "message NOT received correctly");
	  //ignore the message carrier
    }

}

void
P1906MOLReceiverCommunicationInterface::SetDelay (double delay)
{
  NS_LOG_FUNCTION (this << delay);
  m_delay = delay;
}

double
P1906MOLReceiverCommunicationInterface::GetDelay (void)
{
  NS_LOG_FUNCTION (this);
  return m_delay;
}

void
P1906MOLReceiverCommunicationInterface::SetNumMol (double nummol)
{
  NS_LOG_FUNCTION (this << nummol);
  m_nummol = nummol;
}

double
P1906MOLReceiverCommunicationInterface::GetNumMol (void)
{
  NS_LOG_FUNCTION (this);
  return m_nummol;
}

void
P1906MOLReceiverCommunicationInterface::SetDistance (double distance)
{
  NS_LOG_FUNCTION (this << distance);
  m_distance = distance;
}

double
P1906MOLReceiverCommunicationInterface::GetDistance (void)
{
  NS_LOG_FUNCTION (this);
  return m_distance;
}

void
P1906MOLReceiverCommunicationInterface::SetMnsTx (std::vector <std::vector<int> > mnstx)
{
  //NS_LOG_FUNCTION (this << mnstx);
  m_mnstx = mnstx;
}

std::vector <std::vector<int> >
P1906MOLReceiverCommunicationInterface::GetMnsTx (void)
{
  //NS_LOG_FUNCTION (this);
  return m_mnstx;
}

void
P1906MOLReceiverCommunicationInterface::SetRadio (double radio)
{
  //NS_LOG_FUNCTION (this << );
  m_radio = radio;
}

double
P1906MOLReceiverCommunicationInterface::GetRadio (void)
{
  //NS_LOG_FUNCTION (this);
  return m_radio;
}


} // namespace ns3
