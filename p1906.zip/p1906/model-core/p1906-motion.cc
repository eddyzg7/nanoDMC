/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 *  Copyright � 2014 by IEEE.
 *
 *  This source file is an essential part of IEEE P1906.1,
 *  Recommended Practice for Nanoscale and Molecular
 *  Communication Framework.
 *  Verbatim copies of this source file may be used and
 *  distributed without restriction. Modifications to this source
 *  file as permitted in IEEE P1906.1 may also be made and
 *  distributed. All other uses require permission from the IEEE
 *  Standards Department (stds-ipr@ieee.org). All other rights
 *  reserved.
 *
 *  This source file is provided on an AS IS basis.
 *  The IEEE disclaims ANY WARRANTY EXPRESS OR IMPLIED INCLUDING
 *  ANY WARRANTY OF MERCHANTABILITY AND FITNESS FOR USE FOR A
 *  PARTICULAR PURPOSE.
 *  The user of the source file shall indemnify and hold
 *  IEEE harmless from any damages or liability arising out of
 *  the use thereof.
 *
 * Author: Giuseppe Piro - Telematics Lab Research Group
 *                         Politecnico di Bari
 *                         giuseppe.piro@poliba.it
 *                         telematics.poliba.it/piro
 *
 * Editors: Paúl Calderón - Eddy Zúñiga	-	Students of the University of Cuenca - Ecuador
 * 											paul.calderon06@ucuenca.edu.ec
 * 											eddy.zuniga@ucuenca.edu.ec
 * 											30/04/2021
 */


#include "ns3/log.h"

#include "p1906-motion.h"
#include "p1906-communication-interface.h"
#include "p1906-message-carrier.h"
#include "p1906-field.h"
#include <vector>

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("P1906Motion");

TypeId P1906Motion::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::P1906Motion")
    .SetParent<Object> ();
  return tid;
}

P1906Motion::P1906Motion ()
{
  NS_LOG_FUNCTION (this);
}

P1906Motion::~P1906Motion ()
{
  NS_LOG_FUNCTION (this);
}


double
P1906Motion::ComputePropagationDelay (Ptr<P1906CommunicationInterface> src,
		                             Ptr<P1906CommunicationInterface> dst,
		                             Ptr<P1906MessageCarrier> message,
		                             Ptr<P1906Field> field)
{
  NS_LOG_FUNCTION (this << "Return the defaul value: 0s");
  return 0.;
}


Ptr<P1906MessageCarrier>
P1906Motion::CalculateReceivedMessageCarrier(Ptr<P1906CommunicationInterface> src,
		                                    Ptr<P1906CommunicationInterface> dst,
											Ptr<P1906MessageCarrier> message,
											std::vector < std::vector<double> > RxTime,
		                                    Ptr<P1906Field> field)
{
  NS_LOG_FUNCTION (this << "apply default behavior: do nothing");
  return message;
}

double
P1906Motion::Getdelay (void)
{
  NS_LOG_FUNCTION (this);
  return 0;
}

void
P1906Motion::Setdelay (double d)
{
  NS_LOG_FUNCTION (this << d);
}

double
P1906Motion::GetDeltat (void)
{
  NS_LOG_FUNCTION (this);
  return m_deltat;
}

void
P1906Motion::SetDeltat (double deltat)
{
  NS_LOG_FUNCTION (this << deltat);
  m_deltat = deltat;
}


std::vector <std::vector<double> >
P1906Motion::BrownianMotion (std::vector <std::vector<double> > vectorXY)
{
  NS_LOG_FUNCTION (this);

  //std::vector < std::vector<double> > xy_return(m_slot, std::vector<double>(2));
  return vectorXY;
}

std::vector <std::vector<double> >
P1906Motion::BrownianMotionDrift (std::vector <std::vector<double> > vectorXY, Ptr<P1906Field> field)
{
  NS_LOG_FUNCTION (this);

  //std::vector < std::vector<double> > xy_return(m_slot, std::vector<double>(2));
  return vectorXY;
}


double
P1906Motion::GetTimeTs (void)
{
  NS_LOG_FUNCTION (this);
  return m_ts;
}

void
P1906Motion::SetTimeTs (double ts)
{
  NS_LOG_FUNCTION (this << ts);
  m_ts = ts;
}

int
P1906Motion::GetNumPaquet (void)
{
  NS_LOG_FUNCTION (this);
  return m_numpaquet;
}

void
P1906Motion::SetNumPaquet (int numpaquet)
{
  NS_LOG_FUNCTION (this << numpaquet);
  m_numpaquet = numpaquet;
}

double
P1906Motion::GetTw (void)
{
  NS_LOG_FUNCTION (this);
  return m_tw;
}

void
P1906Motion::SetTw (double tw)
{
  NS_LOG_FUNCTION (this << tw);
  m_tw = tw;
}

double
P1906Motion::GetnOfMol (void)
{
  NS_LOG_FUNCTION (this);
  return m_nOfMol;
}

void
P1906Motion::SetnOfMol (double nOfMol)
{
  NS_LOG_FUNCTION (this << nOfMol);
  m_nOfMol = nOfMol;
}

} // namespace ns3
