/* -- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -- */
/*
 *  Copyright � 2014 by IEEE.
 *
 *  This source file is an essential part of IEEE P1906.1,
 *  Recommended Practice for Nanoscale and Molecular
 *  Communication Framework.
 *  Verbatim copies of this source file may be used and
 *  distributed without restriction. Modifications to this source
 *  file as permitted in IEEE P1906.1 may also be made and
 *  distributed. All other uses require permission from the IEEE
 *  Standards Department (stds-ipr@ieee.org). All other rights
 *  reserved.
 *
 *  This source file is provided on an AS IS basis.
 *  The IEEE disclaims ANY WARRANTY EXPRESS OR IMPLIED INCLUDING
 *  ANY WARRANTY OF MERCHANTABILITY AND FITNESS FOR USE FOR A
 *  PARTICULAR PURPOSE.
 *  The user of the source file shall indemnify and hold
 *  IEEE harmless from any damages or liability arising out of
 *  the use thereof.
 *
 * Author: Giuseppe Piro - Telematics Lab Research Group
 *                         Politecnico di Bari
 *                         giuseppe.piro@poliba.it
 *                         telematics.poliba.it/piro
 *
 * Editors: Paúl Calderón - Eddy Zúñiga	-	Students of the University of Cuenca - Ecuador
 * 											paul.calderon06@ucuenca.edu.ec
 * 											eddy.zuniga@ucuenca.edu.ec
 * 											30/04/2021
 */


#include "ns3/object.h"
#include "ns3/packet.h"
#include "ns3/simulator.h"
#include "ns3/net-device.h"
#include "ns3/node.h"
#include "ns3/log.h"
#include "ns3/pointer.h"
#include "p1906-medium.h"
#include "p1906-communication-interface.h"
#include "p1906-field.h"
#include "p1906-message-carrier.h"
#include "p1906-receiver-communication-interface.h"
#include "p1906-specificity.h"
#include "p1906-motion.h"
#include "ns3/p1906-mol-motion.h"
#include <vector>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <string.h>
#include <stdio.h>

#include <fstream>
//#include "p1906-mol-motion.h"


NS_LOG_COMPONENT_DEFINE ("P1906Medium");

namespace ns3 {

std::ofstream output;
std::ofstream output1;

NS_OBJECT_ENSURE_REGISTERED (P1906Medium);

TypeId
P1906Medium::GetTypeId ()
{
  static TypeId tid = TypeId ("ns3::P1906Medium")
    .SetParent<Channel> ()
    .AddConstructor<P1906Medium> ();

  return tid;
}

P1906Medium::P1906Medium ()
  : Channel ()
{
  NS_LOG_FUNCTION (this);
  m_communicationInterfaces = new P1906CommunicationInterfaces ();
  m_motion = 0;
}

P1906Medium::~P1906Medium ()
{
  NS_LOG_FUNCTION (this);
  m_communicationInterfaces = 0;
  m_motion = 0;
}

void
P1906Medium::DoDispose ()
{
  Channel::DoDispose ();
  m_communicationInterfaces = 0;
  m_motion = 0;
  NS_LOG_FUNCTION (this);
}

uint32_t
P1906Medium::GetNDevices () const
{
  NS_LOG_FUNCTION (this);
  return 0;//NOT USED IN P1906
}

Ptr<NetDevice>
P1906Medium::GetDevice (uint32_t i) const
{
  NS_LOG_FUNCTION (this);
  return 0; //NOT USED IN P1906
}

void
P1906Medium::SetP1906Motion (Ptr<P1906Motion> f)
{
  NS_LOG_FUNCTION (this);
  m_motion = f;
}

Ptr<P1906Motion>
P1906Medium::GetP1906Motion ()
{
  NS_LOG_FUNCTION (this);
  return m_motion;
}

void
P1906Medium::HandleTransmission (Ptr<P1906CommunicationInterface> src,
                                 Ptr<P1906MessageCarrier> message,
                                 Ptr<P1906Field> field)
{
  NS_LOG_FUNCTION (this);

  Ptr<Packet> p = message->GetMessage ();
  std::vector< Ptr<P1906CommunicationInterface> >::iterator it;
  m_numpaquet = int(p->GetSize());
  m_node=0;

  for (it = m_communicationInterfaces->begin (); it != m_communicationInterfaces->end (); it++)
    {

	  Ptr<P1906CommunicationInterface> dst = *it;
	  if (dst != src)
	    {
          std::vector < std::vector<double> > vector_01(int(p->GetSize())*8, std::vector<double>(2));	//Devuelve el tipo de bit y las moléculas recibidas
          std::vector < std::vector<int> > modulation = message->GetModulation();
          std::vector <double> resultado;
          Ptr<P1906ReceiverCommunicationInterface> rx = dst->GetP1906ReceiverCommunicationInterface ();
          rx->SetMnsTx(message->GetModulation());

          														//Vector de tiempo de llegada de las moléculas recibidas
          														//Número de Bit transmitido
          //double delay;
          double ts;																//Tiempo de simulación
          double tstotal;															//Tiempo de simulación total - tiempo de transmisión
          double tw = message->GetPulseInterval ().GetSeconds ();					//Ancho de pulso - tiempo de bit
          NS_LOG_FUNCTION("TW: " << std::to_string(tw));

          std::string molmod = "";
          // Muestra el mensaje enviado
          for (int m = 0; m<int(p->GetSize()); m++){
        	  for (int c = 0; c<8;c++){
        		  molmod = molmod + std::to_string(modulation[m][c]) + " | ";
        	  }
        	  NS_LOG_FUNCTION("Modulated Molecules: " << molmod);
          }

          delay = m_motion->ComputePropagationDelay (src, dst, message, field);
          ts = delay + (tw/2);														//Tiempo de simulación mas la mitad del ancho de pulso
          //ts = 0.1;
          NS_LOG_FUNCTION("TS: " << delay + (tw/2));
		  tstotal = ts + (tw * ((m_numpaquet*8)-1)); 									//Tiempo de simulación por el número total de bits a transmitir
		  m_delta_t = ts/m_slot;
		  m_numintervaltotal = tstotal/m_delta_t;

		  m_motion->Setdelay(delay);
		  m_motion->SetTimeTs(ts);
		  m_motion->SetDeltat(m_delta_t);
		  m_motion->SetNumPaquet(m_numpaquet);
		  m_motion->SetTw(tw);


		  Ptr<P1906MessageCarrier> receivedMessageCarrier = Transmission(modulation, src, dst, message, field);
		  double Q = 0;
		  double umbral = 0;

		  // Concentration 3D
		  //Q = (3*m_nOfMol) / (2*M_PI);
		  //Q = Q * (1/(pow(m_pos*1000000,2)));
		  //Q = Q * exp(-1.5);

		  // Concentration 2D
		  Q = (m_nOfMol) / (M_PI * pow(m_pos*1000000,2));
		  Q = Q * exp(-1);
		  umbral = Q/2;

		  Simulator::Schedule (Seconds(tstotal), &P1906Medium::HandleReception, this, src, dst, receivedMessageCarrier, umbral);
	    }
    }
}

Ptr<P1906MessageCarrier>
P1906Medium::Transmission(std::vector < std::vector<int> > modulation,
						 Ptr<P1906CommunicationInterface> src,
						 Ptr<P1906CommunicationInterface> dst,
						 Ptr<P1906MessageCarrier> message,
						 Ptr<P1906Field> field)
{
	NS_LOG_FUNCTION (this);
	Ptr<P1906MessageCarrier> receivedMessageCarrier;
	std::string arch;
	std::string tiempo;
	std::string time;
	std::string timeTX;
	int num_bits = 0;
	RxTime.assign(8*m_numpaquet, std::vector<double>(m_nOfMol,0));

	tiempo = "RxTime-" + std::to_string(m_node) + "-" +std::to_string(m_option) +"-"+std::to_string(m_pos)+".csv";
	output1.open (tiempo);

    for (int i_packets=0; i_packets<m_numpaquet; i_packets++){

		  for (int j_bits=0; j_bits<8; j_bits++){

			  if (m_motion)
				{
				  if(m_option==0){
					  arch = "example-" + std::to_string(m_node) + "-0-"+std::to_string(num_bits)+"-"+std::to_string(m_pos)+".csv";
				  }
				  else if (m_option==1){
					  arch = "example-" + std::to_string(m_node) + "-1-"+std::to_string(num_bits)+"-"+std::to_string(m_pos)+".csv";
				  } else {
					  NS_LOG_ERROR(this << "UNDEFINED MOTION");
					  exit(0);
				  }
				   output.open (arch);

				   ReturnBrownian.assign(m_nOfMol, std::vector<double>(4, 0));
			       ReturnBrownianTotal.assign(m_nOfMol, std::vector<double>((m_numintervaltotal*2 + 3), 0));
				   time = "";

				   m_motion->SetnOfMol(modulation[i_packets][j_bits]);

				   for (int h=0; h<m_numintervaltotal; h++)
				   {
					   if(m_option==0){
						   ReturnBrownian = m_motion->BrownianMotion(ReturnBrownian);
					   }
					   else if(m_option==1){
						   ReturnBrownian = m_motion->BrownianMotionDrift(ReturnBrownian,field);
					   }
					   else{
						  NS_LOG_ERROR(this << "UNDEFINED MOTION");
						  exit(0);
					   }

					   ReturnBrownian = receptionVerify (ReturnBrownian, m_pos,0, m_radio, m_delta_t, h);

					   for (int lm=0; lm < int(m_nOfMol); lm++){
						   ReturnBrownianTotal[lm][0] = num_bits;
						   ReturnBrownianTotal[lm][1] = ReturnBrownian[lm][0];
						   ReturnBrownianTotal[lm][2] = ReturnBrownian[lm][1];
						   ReturnBrownianTotal[lm][2*h+3] = ReturnBrownian[lm][2];
						   ReturnBrownianTotal[lm][2*h+4] = ReturnBrownian[lm][3];
					   }
				   }

				   for (int fil = 0; fil < int(m_nOfMol); fil++){
					   for (int col = 0; col < (m_numintervaltotal*2 + 3); col++){
						   output << ReturnBrownianTotal[fil][col] << ",";
					   }
					   output << "" << std::endl;
				   }
				   output.close();

				   timeTX = "TimeBit " + std::to_string(num_bits) + ": ";
				   for (int nmol=0; nmol<m_nOfMol; nmol++){

					   if(ReturnBrownianTotal[nmol][1]==1){
						   RxTime[num_bits][nmol] = ReturnBrownianTotal[nmol][2];
						   output1 << RxTime[num_bits][nmol] << ",";
						   timeTX = timeTX + std::to_string(RxTime[num_bits][nmol])+" | ";
					   }
					   else{
						   output1 << "0" << ",";
					   }
				   }
				   output1 << "" << std::endl;
				   NS_LOG_FUNCTION(timeTX);
				   timeTX="";
				   num_bits = num_bits+1;
				}
			  else
				{
				  NS_LOG_FUNCTION (this << "The Motion component has not been configured");
				  return message;
				}
		  }
    }
    output1.close();
    m_node = m_node + 1;
    m_motion->SetnOfMol(m_nOfMol);
    receivedMessageCarrier = m_motion->CalculateReceivedMessageCarrier(src, dst, message, RxTime, field);
    return receivedMessageCarrier;
}

void
P1906Medium::HandleReception (Ptr<P1906CommunicationInterface> src, Ptr<P1906CommunicationInterface> dst, Ptr<P1906MessageCarrier> carrier, double umbral)
{
  NS_LOG_FUNCTION (this);
  Ptr<P1906ReceiverCommunicationInterface> rx = dst->GetP1906ReceiverCommunicationInterface ();
  rx->SetDelay(delay);
  rx->SetRadio(m_radio);
  rx->HandleReception (src, dst, carrier, umbral);
}

void
P1906Medium::AddP1906CommunicationInterface (Ptr<P1906CommunicationInterface> i)
{
  NS_LOG_FUNCTION (this);
  m_communicationInterfaces->push_back (i);
}

void
P1906Medium::SetP1906CommunicationInterfaces (P1906CommunicationInterfaces* i)
{
  NS_LOG_FUNCTION (this);
  m_communicationInterfaces = i;
}

P1906Medium::P1906CommunicationInterfaces*
P1906Medium::GetP1906CommunicationInterfaces ()
{
  NS_LOG_FUNCTION (this);
  return m_communicationInterfaces;
}

double
P1906Medium::GetnOfMol (void)
{
  NS_LOG_FUNCTION (this);
  return m_nOfMol;
}

void
P1906Medium::SetnOfMol (double nOfMol)
{
  NS_LOG_FUNCTION (this << nOfMol);
  m_nOfMol = nOfMol;
}

double
P1906Medium::Getpos (void)
{
  NS_LOG_FUNCTION (this);
  return m_pos;
}

void
P1906Medium::Setpos (double pos)
{
  NS_LOG_FUNCTION (this << pos);
  m_pos = pos;
}

double
P1906Medium::GetSlot (void)
{
  NS_LOG_FUNCTION (this);
  return m_slot;
}

void
P1906Medium::SetSlot (double slot)
{
  NS_LOG_FUNCTION (this << slot);
  m_slot = slot;
}

double
P1906Medium::GetRadio (void)
{
  NS_LOG_FUNCTION (this);
  return m_radio;
}

void
P1906Medium::SetRadio (double radio)
{
  NS_LOG_FUNCTION (this << radio);
  m_radio = radio;
}


int
P1906Medium::GetMotionFreeOrDrift (void)
{
  //NS_LOG_FUNCTION (this);
  return m_option;
}

void
P1906Medium::SetMotionFreeOrDrift (int option)
{
  //NS_LOG_FUNCTION (this << radio);
  m_option = option;
}


std::vector <std::vector<double> >
P1906Medium::receptionVerify (std::vector <std::vector<double> > molmotion, double x_rx, double y_rx, double radio, double delta_t, int Interval)
{
  //NS_LOG_FUNCTION (this);
  //x_rx  Coordenada x del receptor
  //y_rx  Coordenada y del receptor
  double xi;
  double yi;
  double d;
  std::vector <double> resultado; // vector que contiene tiempo; llegó o no la molécula al receptor
  for (int i = 0; i < int(m_nOfMol); i++){

	  if (molmotion [i][0] == 0)//Verificamos el estado del bit // 0: no llega aún - 1: molécula recibida
	  {
		  xi = molmotion [i][2];
		  yi = molmotion [i][3];
		  d = sqrt(pow(x_rx-xi,2) + pow(y_rx-yi,2));
		  if (d<radio)  {
			  molmotion[i][0] = 1;//Cambio de estado a 1: molécula recibida
			  molmotion[i][1] = Interval*delta_t;//Registro tiempo de llegada
		  }
	  }
  }

  return molmotion;
}

} // namespace ns3
