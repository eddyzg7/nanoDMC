/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 *  Copyright � 2014 by IEEE.
 *
 *  This source file is an essential part of IEEE P1906.1,
 *  Recommended Practice for Nanoscale and Molecular
 *  Communication Framework.
 *  Verbatim copies of this source file may be used and
 *  distributed without restriction. Modifications to this source
 *  file as permitted in IEEE P1906.1 may also be made and
 *  distributed. All other uses require permission from the IEEE
 *  Standards Department (stds-ipr@ieee.org). All other rights
 *  reserved.
 *
 *  This source file is provided on an AS IS basis.
 *  The IEEE disclaims ANY WARRANTY EXPRESS OR IMPLIED INCLUDING
 *  ANY WARRANTY OF MERCHANTABILITY AND FITNESS FOR USE FOR A
 *  PARTICULAR PURPOSE.
 *  The user of the source file shall indemnify and hold
 *  IEEE harmless from any damages or liability arising out of
 *  the use thereof.
 *
 * Author: Giuseppe Piro - Telematics Lab Research Group
 *                         Politecnico di Bari
 *                         giuseppe.piro@poliba.it
 *                         telematics.poliba.it/piro
 *
 * Editors: Paúl Calderón - Eddy Zúñiga	-	Students of the University of Cuenca - Ecuador
 * 											paul.calderon06@ucuenca.edu.ec
 * 											eddy.zuniga@ucuenca.edu.ec
 * 											30/04/2021
 */


#include "ns3/log.h"

#include "p1906-receiver-communication-interface.h"
#include "p1906-net-device.h"
#include <ns3/packet.h>
#include "p1906-specificity.h"
#include "p1906-message-carrier.h"
#include "p1906-communication-interface.h"
#include "p1906-medium.h"
#include "p1906-net-device.h"
#include "p1906-motion.h"


namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("P1906ReceiverCommunicationInterface");

TypeId P1906ReceiverCommunicationInterface::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::P1906ReceiverCommunicationInterface")
    .SetParent<Object> ();
  return tid;
}

P1906ReceiverCommunicationInterface::P1906ReceiverCommunicationInterface ()
{
  NS_LOG_FUNCTION (this);
  SetP1906NetDevice (0);
  m_specificity = 0;
}

P1906ReceiverCommunicationInterface::~P1906ReceiverCommunicationInterface ()
{
  NS_LOG_FUNCTION (this);
  SetP1906NetDevice (0);
  m_specificity = 0;
}

void
P1906ReceiverCommunicationInterface::SetP1906Specificity (Ptr<P1906Specificity> s)
{
  NS_LOG_FUNCTION (this);
  m_specificity = s;
}

Ptr<P1906Specificity>
P1906ReceiverCommunicationInterface::GetP1906Specificity ()
{
  NS_LOG_FUNCTION (this);
  return m_specificity;
}

void
P1906ReceiverCommunicationInterface::SetP1906Nmol (double nmol)
{
  NS_LOG_FUNCTION (this);
  n_mol = nmol;
}

double
P1906ReceiverCommunicationInterface::GetP1906Nmol ()
{
  NS_LOG_FUNCTION (this);
  return n_mol;
}

void
P1906ReceiverCommunicationInterface::SetP1906Limit (double limit)
{
  NS_LOG_FUNCTION (this);
  m_limit = limit;
}

double
P1906ReceiverCommunicationInterface::GetP1906Limit ()
{
  NS_LOG_FUNCTION (this);
  return m_limit;
}

void
P1906ReceiverCommunicationInterface::HandleReception (Ptr<P1906CommunicationInterface> src, Ptr<P1906CommunicationInterface> dst, Ptr<P1906MessageCarrier> message, double umbral)
{
  NS_LOG_FUNCTION (this);

  /*
   * In this part of the code, the received should use the
   * Specificity component to realize if the message can be
   * received or not.
   */

}

void
P1906ReceiverCommunicationInterface::SetP1906CommunicationInterface (Ptr<P1906CommunicationInterface> i)
{
  NS_LOG_FUNCTION (this);
  m_p1906CommunicationInterface = i;
}

Ptr<P1906CommunicationInterface>
P1906ReceiverCommunicationInterface::GetP1906CommunicationInterface (void)
{
  NS_LOG_FUNCTION (this);
  return m_p1906CommunicationInterface;
}

void
P1906ReceiverCommunicationInterface::SetP1906NetDevice (Ptr<P1906NetDevice> d)
{
  NS_LOG_FUNCTION (this);
  m_dev = d;
}

Ptr<P1906NetDevice>
P1906ReceiverCommunicationInterface::GetP1906NetDevice ()
{
  NS_LOG_FUNCTION (this);
  return m_dev;
}

void
P1906ReceiverCommunicationInterface::SetP1906Medium (Ptr<P1906Medium> m)
{
  NS_LOG_FUNCTION (this);
  m_medium = m;
}

Ptr<P1906Medium>
P1906ReceiverCommunicationInterface::GetP1906Medium ()
{
  NS_LOG_FUNCTION (this);
  return m_medium;
}

void
P1906ReceiverCommunicationInterface::SetDelay (double delay)
{
  NS_LOG_FUNCTION (this << delay);
  m_delay = delay;
}

double
P1906ReceiverCommunicationInterface::GetDelay (void)
{
  NS_LOG_FUNCTION (this);
  return m_delay;
}

void
P1906ReceiverCommunicationInterface::SetNumMol (double nummol)
{
  NS_LOG_FUNCTION (this << nummol);
  m_nummol = nummol;
}

double
P1906ReceiverCommunicationInterface::GetNumMol (void)
{
  NS_LOG_FUNCTION (this);
  return m_nummol;
}

void
P1906ReceiverCommunicationInterface::SetDistance (double distance)
{
  NS_LOG_FUNCTION (this << distance);
  m_distance = distance;
}

double
P1906ReceiverCommunicationInterface::GetDistance (void)
{
  NS_LOG_FUNCTION (this);
  return m_distance;
}

void
P1906ReceiverCommunicationInterface::SetMnsTx (std::vector <std::vector<int> > mnstx)
{
  //NS_LOG_FUNCTION (this << mnstx);
  m_mnstx = mnstx;
}

std::vector <std::vector<int> >
P1906ReceiverCommunicationInterface::GetMnsTx (void)
{
  //NS_LOG_FUNCTION (this);
  return m_mnstx;
}

void
P1906ReceiverCommunicationInterface::SetRadio (double radio)
{
  //NS_LOG_FUNCTION (this << );
  m_radio = radio;
}

double
P1906ReceiverCommunicationInterface::GetRadio (void)
{
  //NS_LOG_FUNCTION (this);
  return m_radio;
}

} // namespace ns3



